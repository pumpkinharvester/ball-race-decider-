w = display.contentWidth
h = display.contentHeight
r = math.random()
r2 = math.random()
local physics = require("physics")
    physics.start() 
    physics.pause()
    physics.setGravity(0, 10)
    local floor = display.newRect(w*0.5, h*1.25, w*4, h*0.01)
physics.addBody(floor, "static")
floor.name = "floor"


local wall = display.newRect(w*0.001, h*0.5, w*0.01, h*10)
physics.addBody(wall, "static", {bounce = 1})

local wall2 = display.newRect(w*1, h*0.5, w*0.01, h*10)
physics.addBody(wall2, "static", {bounce = 1})

local circ = display.newCircle(w*r, -50, h/50)
physics.addBody(circ, "dynamic", {bounce = 0.2})
circ:setFillColor(255/255, 0/255, 0/255)
circ.name = "red"
circ:applyForce(0,1,circ.x,circ.y)
local circ2 = display.newCircle(w*r2, -50, h/50)
physics.addBody(circ2, "dynamic", {bounce = 0.2})
circ2:setFillColor(0/255, 0/255, 255/255)
circ2.name = "blue"
-- very very yummy spaghetti code
for i = 1, 100, 10 do
    peg = display.newCircle( i*4, 8*i, 8,8)
physics.addBody( peg, "static", {bounce = 0.5})
peg.name = "peg"
end

for i = 1, 100, 10 do
    peg2 = display.newCircle( i*4 + 50, 8*i, 8,8)
physics.addBody( peg2, "static", {bounce = 0.5})
peg2.name = "peg"
end

for i = 1, 100, 10 do
    peg3 = display.newCircle( i*4 + 100, 8*i, 8,8)
physics.addBody( peg3, "static", {bounce = 0.5})
peg3.name = "peg"
end

for i = 1, 100, 10 do
    peg4 = display.newCircle( i*4 + 150, 8*i, 8,8)
physics.addBody( peg4, "static", {bounce = 0.5})
peg4.name = "peg"
end

for i = 1, 100, 10 do
    peg5 = display.newCircle( i*4 + 200, 8*i, 8,8)
physics.addBody( peg5, "static", {bounce = 0.5})
peg5.name = "peg"
end

for i = 1, 100, 10 do
    peg6 = display.newCircle( i*4 + 250, 8*i, 8,8)
physics.addBody( peg4, "static", {bounce = 0.5})
peg6.name = "peg"
end

for i = 1, 100, 10 do
    peg7 = display.newCircle( i*4 + 300, 8*i, 8,8)
physics.addBody( peg7, "static", {bounce = 0.5})
peg7.name = "peg"
end

for i = 1, 100, 10 do
    peg8 = display.newCircle( i*4 - 50, 8*i, 8,8)
physics.addBody( peg8, "static", {bounce = 0.5})
peg8.name = "peg"
end

for i = 1, 100, 10 do
    peg9 = display.newCircle( i*4 - 100, 8*i, 8,8)
physics.addBody( peg9, "static", {bounce = 0.5})
peg9.name = "peg"
end

for i = 1, 100, 10 do
    peg10 = display.newCircle( i*4 - 150, 8*i, 8,8)
physics.addBody( peg10, "static", {bounce = 0.5})
peg10.name = "peg"
end

for i = 1, 100, 10 do
    peg11 = display.newCircle( i*4 - 200, 8*i, 8,8)
physics.addBody( peg11, "static", {bounce = 0.5})
peg11.name = "peg"
end

for i = 1, 100, 10 do
    peg12 = display.newCircle( i*4 - 250, 8*i, 8,8)
    physics.addBody( peg12, "static", {bounce = 0.5})
    peg12.name = "peg"
end

--ui
backgrnd = display.newRect(w*0.5, h*1, 1000, 2000)
backgrnd:setFillColor(0/255, 0/255, 0/255)
startBtn = display.newRect( w*0.5, h*1, 100, 60 )
startBtn:setFillColor(0/255, 255/255, 0/255)
startBtnText = display.newText("start", w*0.5, h*1, nil, 50)
circRep1 = display.newCircle( w*0.75, h*0.5, h*0.1 )
circRep2 = display.newCircle( w*0.25, h*0.5, h*0.1)
circRep1:setFillColor(255/255, 0/255, 0/255)
circRep2:setFillColor(0/255, 0/255, 255/255)
txtBoxRed = native.newTextField( w*0.75, h*0.6, w*0.2, h*0.1 )
txtBoxBlue = native.newTextField( w*0.25, h*0.6, w*0.2, h*0.1 )
txtName = display.newText("Name the balls", w*0.5, h*0.6, nil, 50 )
txtTitle = display.newText("Ball Race Decider", w*0.5, h*0.1, nil, 50)
local physics = require("physics")
    physics.start() 
    physics.pause()
    physics.setGravity(0, 10)
--function
function start (event)
physics.start()
display.remove( startBtn )
display.remove( startBtnReplace )
display.remove(backgrnd)
display.remove(circRep1)
display.remove(circRep2)
display.remove(startBtnText)
txtBoxBlue.y = display.contentHeight * 4
txtBoxRed.y = display.contentHeight * 4
end

startBtn:addEventListener("tap", start)


function win (event)
 obj = event.other
 resetBtn
    winTextRed = txtBoxRed.text
    winTextBlue = txtBoxBlue.text
    print(obj.name)
    if obj.name == "red" then
        backGroundRed = display.newRect( w*1, h*1, 1000, 10000000)
    backGroundRed:setFillColor(80/255,80/255,80/255) 
    redWin = display.newCircle( w*0.5, h*0.5, h*0.3 )
    redWin:setFillColor(255/255, 0/255, 0/255)
    display.newText( winTextRed.. " wins!", w*0.5, h*0.5, nil, 45)
    physics.pause()     
elseif obj.name == "blue" then
    backGroundBlue = display.newRect( w*1, h*1, 1000, 10000000)
    backGroundBlue:setFillColor(80/255,80/255,80/255)             
    blueWin = display.newCircle(w*0.5, h*0.5, h*0.3)
    blueWin:setFillColor(0/255, 0/255, 255/255)
    display.newText( winTextBlue.. " wins!", w*0.5, h*0.5, nil, 45)
    physics.pause()
 end
end
floor:addEventListener("collision", win)